arr={
    design:"https://en.wikipedia.org/wiki/Web_design",
    history: "https://en.wikipedia.org/wiki/History_of_the_World_Wide_Web",
    crawl: "https://en.wikipedia.org/wiki/Web_crawler"
};
